import java.util.ArrayList;

public class Tablero {

	ArrayList<Integer> fila = new ArrayList<Integer>();
	
	ArrayList<ArrayList<Integer>> tablero = new ArrayList<>();
	
	
	Tablero() {
		
		
		for(int i = 1; i<= 8; i ++) {
			this.fila.add(0);
		}
		
		for(int i = 1; i<= 8; i ++) {
			this.tablero.add(fila);
		}
		
		
	}

	public ArrayList<ArrayList<Integer>> getTablero() {
		return tablero;
	}
	
	
}
