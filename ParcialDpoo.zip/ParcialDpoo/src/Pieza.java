
public abstract class Pieza {

	int posInicialX;
	int posInicialY;
	Tablero tablero;
	
	Pieza(int x, int y){
		this.posInicialX = x;
		this.posInicialY = y;
		this.tablero = new Tablero();
	
	}
	
	
	
	public abstract int getCasillasAlcanzables();
	
}
