
public class Peon extends Pieza{

	Peon(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCasillasAlcanzables() {
		// TODO Auto-generated method stub
		
		int casillasAlcanzables = 0;
		
		
		if( posInicialY == 2 ) {
			
			casillasAlcanzables = 2;
			
		}
		else {
			casillasAlcanzables = 1; // si el peon se encuentra en la posición (n, 1) se considerará que solo puede moverse 1 vez. Esto es posible en algunas variantes.
		}
		
		if( posInicialY == 8 ) {
			
			casillasAlcanzables = 0;
			
		}
		
		
		
		
		return casillasAlcanzables;
	}

	
}
