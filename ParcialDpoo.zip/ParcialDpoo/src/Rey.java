
public class Rey extends Pieza{

	Rey(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int getCasillasAlcanzables() {
		
		int casillasAlcanzables = 8;
		
		
		boolean extremoX = ((posInicialX == 1) |  (posInicialX == 8)  );
		boolean extremoY = ((posInicialY == 1) |  (posInicialY == 8)  );
		
		if (extremoX | extremoY) {
			casillasAlcanzables = 5;
		}
		if (extremoX && extremoY) {
			casillasAlcanzables = 3;
		}
		
		
		return casillasAlcanzables;
	}
	
	
	

}
