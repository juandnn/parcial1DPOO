

public class Torre extends Pieza{

		Torre(int x, int y) {
			super(x, y);
			// TODO Auto-generated constructor stub
		}

		@Override
		public int getCasillasAlcanzables() {
			// TODO Auto-generated method stub
			return 14; // la torre, en un tablero vacio, siempre se puede mover a 14 casillas diferentes.
		}

}


