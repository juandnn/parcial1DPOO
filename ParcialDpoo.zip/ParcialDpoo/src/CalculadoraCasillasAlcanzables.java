
public class CalculadoraCasillasAlcanzables {
	
	static int x = 1;  // aqui se cambia la posicion en x (1 a 8)
	static int y = 1; // aqui se cambia la posicion en y (1 a 8)
			
	
	static Peon peon = new Peon(x,y );
	static Rey rey = new Rey(x,y );
	static Torre torre = new Torre(x,y );
			
	
	
	
	public static void main(String args[]) {
		Tablero tablero = new Tablero();
		
		if ( ((x<= 8) && (x > 0) ) && ((y<= 8) && (y > 0) )  ) {
			System.out.print("si es peon: ");
			System.out.println(peon.getCasillasAlcanzables());
			System.out.print("si es rey: ");
			System.out.println(rey.getCasillasAlcanzables());
			System.out.print("si es torre: ");
			System.out.println(torre.getCasillasAlcanzables());
		}
		
		else {
			System.out.print("La posicion esta fuera del tablero");
		}
		
		

		
		
	}
	
	
	
	
	

}
